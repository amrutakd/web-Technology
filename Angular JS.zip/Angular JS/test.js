var app = angular.module('todoApp', []);

app.controller('todocontroller', function($scope) {
    $scope.tasks = []; // Renamed to match the HTML

    // Function to add a task
    $scope.addTask = function() {
        if ($scope.newTask) {
            $scope.tasks.push({ text: $scope.newTask, editing: false });
            $scope.newTask = ''; // Clear the input field
        }
    };

    // Function to delete a task
    $scope.deleteTask = function(index) {
        $scope.tasks.splice(index, 1);
    };

    // Function to edit a task
    $scope.editTask = function(task) {
        task.editing = !task.editing;
    };
});
